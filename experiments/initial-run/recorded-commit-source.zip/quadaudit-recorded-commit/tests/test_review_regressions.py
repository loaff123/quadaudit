import unittest
from fractions import Fraction as F
from unittest.mock import patch
from quadaudit.model import Case,Segment
from quadaudit.adapters import RunConfig,run_case
from quadaudit.instrumentation import represented

class NumericalReviewRegressions(unittest.TestCase):
    def test_mpf_nonfinite_rejected(self):
        import mpmath as mp
        for x in [mp.inf,-mp.inf,mp.nan]:
            with self.subTest(x=x), self.assertRaises(ValueError): represented(x)
    def test_invalid_estimate_keeps_finite_accuracy(self):
        c=Case('zero','power',(Segment(F(0),F(1),(F(0),)),),F(0))
        with patch('scipy.integrate.quad',return_value=(0.,float('nan'),{'neval':0})):
            r=run_case(c,RunConfig())
        self.assertEqual(r['outcome'],'returned'); self.assertEqual(r['value'],'0')
        self.assertEqual(r['adjudication']['accuracy'],'accurate')
        self.assertEqual(r['adjudication']['estimate'],'invalid')
    def test_negative_piece_cannot_be_hidden(self):
        c=Case('zero','staircase',(Segment(F(0),F(1,2),(F(0),)),Segment(F(1,2),F(1),(F(0),))),F(0))
        with patch('scipy.integrate.quad',side_effect=[(0.,-1.,{'neval':0}),(0.,2.,{'neval':0})]):
            r=run_case(c,RunConfig(track='split'))
        self.assertEqual(r['adjudication']['accuracy'],'accurate')
        self.assertEqual(r['adjudication']['estimate'],'invalid')
        self.assertIsNone(r['error_estimate'])

    def test_trace_does_not_change_nonfinite_callback(self):
        from quadaudit.instrumentation import BudgetCounter
        for trace in [0,1]:
            c=BudgetCounter(10,trace)
            self.assertEqual(c.call_scalar(0.0,lambda x:float('inf')),float('inf'))
            if trace: self.assertIsNone(c.trace[0]['y'])
    def test_started_and_completed_are_distinct(self):
        from quadaudit.instrumentation import BudgetCounter
        c=BudgetCounter(3,0)
        def boom(x): raise RuntimeError('test callback failure')
        with self.assertRaises(RuntimeError): c.call_scalar(1.,boom)
        self.assertEqual(c.to_dict()['evaluations'],1)
        self.assertEqual(c.to_dict()['completed_evaluations'],0)
    def test_budget_primitives_validate(self):
        from quadaudit.instrumentation import BudgetCounter
        for invalid in [-1,True,1.5]:
            with self.assertRaises(ValueError): BudgetCounter(invalid)
        c=BudgetCounter(3)
        with self.assertRaises(ValueError): c.reserve(-1)
    def test_case_metadata_immutable(self):
        p={'amplitude':'1'}
        c=Case('zero','power',(Segment(F(0),F(1),(F(0),)),),F(0),p)
        p['amplitude']='999'
        self.assertEqual(c.parameters['amplitude'],'1')
        d=c.to_dict(); d['parameters']['amplitude']='2'
        self.assertEqual(c.parameters['amplitude'],'1')
        with self.assertRaises(TypeError): c.parameters['amplitude']='3'
    def test_invalid_estimate_axis_without_reference(self):
        from quadaudit.oracle import Reference,adjudicate
        r=adjudicate(None,Reference(None,None,False),F(1),F(-1))
        self.assertEqual(r['estimate'],'invalid')

    def test_exact_evaluation_rejects_floating_input(self):
        c=Case('square','power',(Segment(F(0),F(1),(F(0),F(0),F(1))),),F(1,3))
        with self.assertRaises(ValueError): c.evaluate_exact(0.1)
        with self.assertRaises(ValueError): c.segments[0].evaluate(0.1)
        self.assertEqual(c.evaluate_exact(F(1,2**1100)),F(1,2**2200))
    def test_mpmath_callback_precision_recorded(self):
        c=Case('square','power',(Segment(F(0),F(1),(F(0),F(0),F(1))),),F(1,3))
        r=run_case(c,RunConfig(method='mpmath_tanhsinh',precision=80))
        self.assertEqual(r['callback_precision_bits_observed'],[100])
        self.assertEqual(r['output_precision_bits'],80)

# Automated numerical review record

An independent automated reviewer inspected the initial mathematical kernel, adapters and instrumentation before the main frozen run. This is not external human numerical certification.

The reviewer ran 180 independent exact Lagrange-integration/transformation/aligned-sum trials, 9,520 exact enclosure combinations, and 5,000 nearest-neighbor 53-bit rounding trials. Those sampled checks found no errors in the finite algebra and adjudication exercised.

It did find consequential implementation errors. Every item below has a failing-then-passing regression in tests/test_review_regressions.py:

- mpmath special-value conversion could map infinity to zero: reject all nonfinite special representations before rational conversion
- Invalid error estimates erased finite value accuracy: parse these axes independently
- A negative piece estimate could disappear in a positive aggregate: any invalid piece invalidates aggregate estimate adequacy
- Trace capture could alter nonfinite callback behavior: record nonfinite evidence without changing native control flow
- Counts called completed included failed callbacks: distinguish charged/started and completed scalar evaluations
- Case metadata could be mutated through an alias: defensive immutable mapping and copy-on-serialization
- Exact evaluators silently accepted floats: reject floating input without imposing serialization bit limits on runtime Fractions
- mpmath guard precision was hidden: record actual callback precision separately from output precision
- Primitive budget inputs were not validated: enforce supported integer ranges
- Invalid estimates became missing without a reference: preserve validity independently of reference availability

The initial defects were caught before frozen main-study execution. The source history and regression tests preserve their existence and repairs. Further whole-project review is required before the release candidate is handed off.
